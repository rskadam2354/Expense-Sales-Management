﻿
namespace employee_payroll_management
{
    partial class ExpensesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button_addexpense = new System.Windows.Forms.Button();
            this.textBox_advdetails = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button_clearexpense = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox_patpedi = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_advance = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button_totalexp = new System.Windows.Forms.Button();
            this.textBox_totalexp = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_othrdetails = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_other = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker_date3 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_mayur = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DataGridView_expense = new Guna.UI2.WinForms.Guna2DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_expense)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_addexpense
            // 
            this.button_addexpense.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button_addexpense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_addexpense.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_addexpense.ForeColor = System.Drawing.Color.White;
            this.button_addexpense.Location = new System.Drawing.Point(898, 200);
            this.button_addexpense.Name = "button_addexpense";
            this.button_addexpense.Size = new System.Drawing.Size(114, 39);
            this.button_addexpense.TabIndex = 49;
            this.button_addexpense.Text = "Add";
            this.button_addexpense.UseVisualStyleBackColor = false;
            this.button_addexpense.Click += new System.EventHandler(this.button_addexpense_Click);
            // 
            // textBox_advdetails
            // 
            this.textBox_advdetails.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_advdetails.Location = new System.Drawing.Point(367, 59);
            this.textBox_advdetails.Multiline = true;
            this.textBox_advdetails.Name = "textBox_advdetails";
            this.textBox_advdetails.Size = new System.Drawing.Size(166, 104);
            this.textBox_advdetails.TabIndex = 44;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(215, 62);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(154, 20);
            this.label11.TabIndex = 43;
            this.label11.Text = "Advance Details :";
            // 
            // button_clearexpense
            // 
            this.button_clearexpense.BackColor = System.Drawing.Color.Red;
            this.button_clearexpense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_clearexpense.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clearexpense.ForeColor = System.Drawing.Color.White;
            this.button_clearexpense.Location = new System.Drawing.Point(767, 201);
            this.button_clearexpense.Name = "button_clearexpense";
            this.button_clearexpense.Size = new System.Drawing.Size(114, 39);
            this.button_clearexpense.TabIndex = 39;
            this.button_clearexpense.Text = "Clear";
            this.button_clearexpense.UseVisualStyleBackColor = false;
            this.button_clearexpense.Click += new System.EventHandler(this.button_clearexpense_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1039, 10);
            this.panel3.TabIndex = 38;
            // 
            // textBox_patpedi
            // 
            this.textBox_patpedi.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_patpedi.Location = new System.Drawing.Point(872, 15);
            this.textBox_patpedi.Name = "textBox_patpedi";
            this.textBox_patpedi.Size = new System.Drawing.Size(155, 27);
            this.textBox_patpedi.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(783, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 20);
            this.label6.TabIndex = 34;
            this.label6.Text = "Patpedi :";
            // 
            // textBox_advance
            // 
            this.textBox_advance.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_advance.Location = new System.Drawing.Point(91, 59);
            this.textBox_advance.Name = "textBox_advance";
            this.textBox_advance.Size = new System.Drawing.Size(120, 27);
            this.textBox_advance.TabIndex = 31;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 20);
            this.label5.TabIndex = 30;
            this.label5.Text = "Advance :";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button_totalexp);
            this.panel2.Controls.Add(this.textBox_totalexp);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.textBox_othrdetails);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.textBox_other);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.button_addexpense);
            this.panel2.Controls.Add(this.textBox_advdetails);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.button_clearexpense);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.textBox_patpedi);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.textBox_advance);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.dateTimePicker_date3);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textBox_mayur);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 344);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1039, 250);
            this.panel2.TabIndex = 41;
            // 
            // button_totalexp
            // 
            this.button_totalexp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button_totalexp.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_totalexp.ForeColor = System.Drawing.Color.White;
            this.button_totalexp.Location = new System.Drawing.Point(109, 194);
            this.button_totalexp.Name = "button_totalexp";
            this.button_totalexp.Size = new System.Drawing.Size(230, 39);
            this.button_totalexp.TabIndex = 56;
            this.button_totalexp.Text = "Calculate Total Expense";
            this.button_totalexp.UseVisualStyleBackColor = false;
            this.button_totalexp.Click += new System.EventHandler(this.button_totalexp_Click);
            // 
            // textBox_totalexp
            // 
            this.textBox_totalexp.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_totalexp.Location = new System.Drawing.Point(514, 200);
            this.textBox_totalexp.Name = "textBox_totalexp";
            this.textBox_totalexp.Size = new System.Drawing.Size(154, 27);
            this.textBox_totalexp.TabIndex = 55;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(370, 203);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 20);
            this.label8.TabIndex = 54;
            this.label8.Text = "Total Expense :";
            // 
            // textBox_othrdetails
            // 
            this.textBox_othrdetails.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_othrdetails.Location = new System.Drawing.Point(865, 62);
            this.textBox_othrdetails.Multiline = true;
            this.textBox_othrdetails.Name = "textBox_othrdetails";
            this.textBox_othrdetails.Size = new System.Drawing.Size(166, 104);
            this.textBox_othrdetails.TabIndex = 53;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(736, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 20);
            this.label2.TabIndex = 52;
            this.label2.Text = "Other Details :";
            // 
            // textBox_other
            // 
            this.textBox_other.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_other.Location = new System.Drawing.Point(608, 62);
            this.textBox_other.Name = "textBox_other";
            this.textBox_other.Size = new System.Drawing.Size(120, 27);
            this.textBox_other.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(543, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 20);
            this.label4.TabIndex = 50;
            this.label4.Text = "Other :";
            // 
            // dateTimePicker_date3
            // 
            this.dateTimePicker_date3.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_date3.Location = new System.Drawing.Point(79, 17);
            this.dateTimePicker_date3.Name = "dateTimePicker_date3";
            this.dateTimePicker_date3.Size = new System.Drawing.Size(296, 27);
            this.dateTimePicker_date3.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 20);
            this.label3.TabIndex = 25;
            this.label3.Text = "Date :";
            // 
            // textBox_mayur
            // 
            this.textBox_mayur.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mayur.Location = new System.Drawing.Point(498, 16);
            this.textBox_mayur.Name = "textBox_mayur";
            this.textBox_mayur.Size = new System.Drawing.Size(161, 27);
            this.textBox_mayur.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(420, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Mayur :";
            // 
            // DataGridView_expense
            // 
            this.DataGridView_expense.AllowUserToAddRows = false;
            this.DataGridView_expense.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.DataGridView_expense.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.DataGridView_expense.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridView_expense.BackgroundColor = System.Drawing.Color.DarkGray;
            this.DataGridView_expense.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridView_expense.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridView_expense.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView_expense.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.DataGridView_expense.ColumnHeadersHeight = 24;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView_expense.DefaultCellStyle = dataGridViewCellStyle6;
            this.DataGridView_expense.EnableHeadersVisualStyles = false;
            this.DataGridView_expense.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridView_expense.Location = new System.Drawing.Point(0, 55);
            this.DataGridView_expense.Name = "DataGridView_expense";
            this.DataGridView_expense.RowHeadersVisible = false;
            this.DataGridView_expense.RowTemplate.Height = 100;
            this.DataGridView_expense.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView_expense.Size = new System.Drawing.Size(1039, 287);
            this.DataGridView_expense.TabIndex = 39;
            this.DataGridView_expense.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.DataGridView_expense.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridView_expense.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DataGridView_expense.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DataGridView_expense.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DataGridView_expense.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DataGridView_expense.ThemeStyle.BackColor = System.Drawing.Color.DarkGray;
            this.DataGridView_expense.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridView_expense.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.DataGridView_expense.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DataGridView_expense.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DataGridView_expense.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DataGridView_expense.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DataGridView_expense.ThemeStyle.HeaderStyle.Height = 24;
            this.DataGridView_expense.ThemeStyle.ReadOnly = false;
            this.DataGridView_expense.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridView_expense.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridView_expense.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DataGridView_expense.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DataGridView_expense.ThemeStyle.RowsStyle.Height = 100;
            this.DataGridView_expense.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridView_expense.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(423, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(236, 26);
            this.label7.TabIndex = 0;
            this.label7.Text = "Add Daily Expenses";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1039, 54);
            this.panel1.TabIndex = 40;
            // 
            // ExpensesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 595);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.DataGridView_expense);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ExpensesForm";
            this.Text = "ExpensesForm";
            this.Load += new System.EventHandler(this.ExpensesForm_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_expense)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_addexpense;
        private System.Windows.Forms.TextBox textBox_advdetails;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button_clearexpense;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox_patpedi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_advance;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dateTimePicker_date3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_mayur;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2DataGridView DataGridView_expense;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_totalexp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_othrdetails;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_other;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_totalexp;
    }
}