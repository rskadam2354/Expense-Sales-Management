﻿
namespace employee_payroll_management
{
    partial class ManageSalesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button_calcsales = new System.Windows.Forms.Button();
            this.textBox_sales = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button_update = new System.Windows.Forms.Button();
            this.textBox_closingfund = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button_clearsales2 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox_expense = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_upi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox_salesID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker_date = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_openfund = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.DataGridView_managesales = new Guna.UI2.WinForms.Guna2DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_searchSales = new System.Windows.Forms.Button();
            this.dateTimePicker_search = new System.Windows.Forms.DateTimePicker();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_managesales)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_calcsales
            // 
            this.button_calcsales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button_calcsales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_calcsales.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_calcsales.ForeColor = System.Drawing.Color.White;
            this.button_calcsales.Location = new System.Drawing.Point(379, 144);
            this.button_calcsales.Name = "button_calcsales";
            this.button_calcsales.Size = new System.Drawing.Size(176, 32);
            this.button_calcsales.TabIndex = 52;
            this.button_calcsales.Text = "Calculate Sales";
            this.button_calcsales.UseVisualStyleBackColor = false;
            this.button_calcsales.Click += new System.EventHandler(this.button_calcsales_Click);
            // 
            // textBox_sales
            // 
            this.textBox_sales.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_sales.Location = new System.Drawing.Point(167, 148);
            this.textBox_sales.Name = "textBox_sales";
            this.textBox_sales.Size = new System.Drawing.Size(190, 27);
            this.textBox_sales.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(95, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 50;
            this.label4.Text = "Sales :";
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_update.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update.ForeColor = System.Drawing.Color.White;
            this.button_update.Location = new System.Drawing.Point(898, 200);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(114, 39);
            this.button_update.TabIndex = 49;
            this.button_update.Text = "Update";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // textBox_closingfund
            // 
            this.textBox_closingfund.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_closingfund.Location = new System.Drawing.Point(504, 83);
            this.textBox_closingfund.Name = "textBox_closingfund";
            this.textBox_closingfund.Size = new System.Drawing.Size(154, 27);
            this.textBox_closingfund.TabIndex = 44;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(371, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(127, 20);
            this.label11.TabIndex = 43;
            this.label11.Text = "Closing Fund :";
            // 
            // button_clearsales2
            // 
            this.button_clearsales2.BackColor = System.Drawing.Color.Red;
            this.button_clearsales2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_clearsales2.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clearsales2.ForeColor = System.Drawing.Color.White;
            this.button_clearsales2.Location = new System.Drawing.Point(767, 201);
            this.button_clearsales2.Name = "button_clearsales2";
            this.button_clearsales2.Size = new System.Drawing.Size(114, 39);
            this.button_clearsales2.TabIndex = 39;
            this.button_clearsales2.Text = "Clear";
            this.button_clearsales2.UseVisualStyleBackColor = false;
            this.button_clearsales2.Click += new System.EventHandler(this.button_clearsales2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1039, 10);
            this.panel3.TabIndex = 38;
            // 
            // textBox_expense
            // 
            this.textBox_expense.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_expense.Location = new System.Drawing.Point(862, 30);
            this.textBox_expense.Name = "textBox_expense";
            this.textBox_expense.Size = new System.Drawing.Size(169, 27);
            this.textBox_expense.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(754, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 20);
            this.label6.TabIndex = 34;
            this.label6.Text = "Expenses :";
            // 
            // textBox_upi
            // 
            this.textBox_upi.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_upi.Location = new System.Drawing.Point(167, 83);
            this.textBox_upi.Name = "textBox_upi";
            this.textBox_upi.Size = new System.Drawing.Size(190, 27);
            this.textBox_upi.TabIndex = 31;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(33, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 20);
            this.label5.TabIndex = 30;
            this.label5.Text = "UPI payment :";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox_salesID);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.button_calcsales);
            this.panel2.Controls.Add(this.textBox_sales);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.button_update);
            this.panel2.Controls.Add(this.textBox_closingfund);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.button_clearsales2);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.textBox_expense);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.textBox_upi);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.dateTimePicker_date);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textBox_openfund);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 344);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1039, 250);
            this.panel2.TabIndex = 41;
            // 
            // textBox_salesID
            // 
            this.textBox_salesID.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_salesID.Location = new System.Drawing.Point(873, 83);
            this.textBox_salesID.Name = "textBox_salesID";
            this.textBox_salesID.Size = new System.Drawing.Size(154, 27);
            this.textBox_salesID.TabIndex = 54;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(812, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 20);
            this.label2.TabIndex = 53;
            this.label2.Text = "ID :";
            // 
            // dateTimePicker_date
            // 
            this.dateTimePicker_date.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_date.Location = new System.Drawing.Point(131, 30);
            this.dateTimePicker_date.Name = "dateTimePicker_date";
            this.dateTimePicker_date.Size = new System.Drawing.Size(325, 27);
            this.dateTimePicker_date.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 20);
            this.label3.TabIndex = 25;
            this.label3.Text = "Birth Date :";
            // 
            // textBox_openfund
            // 
            this.textBox_openfund.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_openfund.Location = new System.Drawing.Point(598, 30);
            this.textBox_openfund.Name = "textBox_openfund";
            this.textBox_openfund.Size = new System.Drawing.Size(154, 27);
            this.textBox_openfund.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(462, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Opening Fund :";
            // 
            // DataGridView_managesales
            // 
            this.DataGridView_managesales.AllowUserToAddRows = false;
            this.DataGridView_managesales.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.DataGridView_managesales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.DataGridView_managesales.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridView_managesales.BackgroundColor = System.Drawing.Color.DarkGray;
            this.DataGridView_managesales.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridView_managesales.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridView_managesales.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView_managesales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.DataGridView_managesales.ColumnHeadersHeight = 24;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView_managesales.DefaultCellStyle = dataGridViewCellStyle6;
            this.DataGridView_managesales.EnableHeadersVisualStyles = false;
            this.DataGridView_managesales.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridView_managesales.Location = new System.Drawing.Point(0, 105);
            this.DataGridView_managesales.Name = "DataGridView_managesales";
            this.DataGridView_managesales.RowHeadersVisible = false;
            this.DataGridView_managesales.RowTemplate.Height = 100;
            this.DataGridView_managesales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView_managesales.Size = new System.Drawing.Size(1039, 237);
            this.DataGridView_managesales.TabIndex = 39;
            this.DataGridView_managesales.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.DataGridView_managesales.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridView_managesales.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DataGridView_managesales.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DataGridView_managesales.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DataGridView_managesales.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DataGridView_managesales.ThemeStyle.BackColor = System.Drawing.Color.DarkGray;
            this.DataGridView_managesales.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridView_managesales.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.DataGridView_managesales.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DataGridView_managesales.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DataGridView_managesales.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DataGridView_managesales.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DataGridView_managesales.ThemeStyle.HeaderStyle.Height = 24;
            this.DataGridView_managesales.ThemeStyle.ReadOnly = false;
            this.DataGridView_managesales.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridView_managesales.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridView_managesales.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DataGridView_managesales.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DataGridView_managesales.ThemeStyle.RowsStyle.Height = 100;
            this.DataGridView_managesales.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DataGridView_managesales.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DataGridView_managesales.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_managesales_CellContentClick);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(412, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(237, 26);
            this.label7.TabIndex = 0;
            this.label7.Text = "Manage Daily Sales";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1039, 54);
            this.panel1.TabIndex = 40;
            // 
            // button_searchSales
            // 
            this.button_searchSales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button_searchSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_searchSales.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_searchSales.ForeColor = System.Drawing.Color.White;
            this.button_searchSales.Location = new System.Drawing.Point(913, 60);
            this.button_searchSales.Name = "button_searchSales";
            this.button_searchSales.Size = new System.Drawing.Size(114, 39);
            this.button_searchSales.TabIndex = 50;
            this.button_searchSales.Text = "Search";
            this.button_searchSales.UseVisualStyleBackColor = false;
            this.button_searchSales.Click += new System.EventHandler(this.button_searchSales_Click);
            // 
            // dateTimePicker_search
            // 
            this.dateTimePicker_search.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_search.Location = new System.Drawing.Point(581, 66);
            this.dateTimePicker_search.Name = "dateTimePicker_search";
            this.dateTimePicker_search.Size = new System.Drawing.Size(325, 27);
            this.dateTimePicker_search.TabIndex = 51;
            // 
            // ManageSalesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 595);
            this.Controls.Add(this.dateTimePicker_search);
            this.Controls.Add(this.button_searchSales);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.DataGridView_managesales);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageSalesForm";
            this.Text = "ManageSales";
            this.Load += new System.EventHandler(this.ManageSales_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_managesales)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_calcsales;
        private System.Windows.Forms.TextBox textBox_sales;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.TextBox textBox_closingfund;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button_clearsales2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox_expense;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_upi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dateTimePicker_date;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_openfund;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2DataGridView DataGridView_managesales;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_salesID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_searchSales;
        private System.Windows.Forms.DateTimePicker dateTimePicker_search;
    }
}